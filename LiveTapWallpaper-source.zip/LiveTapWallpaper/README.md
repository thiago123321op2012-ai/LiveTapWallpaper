# LiveTap Wallpaper (protótipo)

Projeto Android Studio de exemplo para Android 8+ (testar no Moto G54 / Android 15).

## O que faz
- Escolhe um vídeo local (exporte a Live Photo como MP4).
- Define um papel de parede animado.
- Ao tocar no papel de parede, tenta reproduzir o vídeo uma vez e retornar ao primeiro quadro.

## Limitações importantes
- É um protótipo de código-fonte, não um APK pronto nem um app testado no Moto G54.
- O suporte a eventos de toque depende de o launcher da Motorola encaminhar os toques ao papel de parede.
- O comportamento do MediaPlayer ao pausar/voltar ao primeiro quadro pode variar conforme codec e aparelho e precisa ser testado; vídeos MP4/H.264 curtos são a melhor primeira tentativa.
- Para compilar: abra a pasta no Android Studio com JDK 17 e Android SDK 35; deixe o Gradle sincronizar e use Build > Build APK(s).
