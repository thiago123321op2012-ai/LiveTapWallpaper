package com.example.livetapwallpaper

import android.service.wallpaper.WallpaperService
import android.view.MotionEvent
import android.view.SurfaceHolder
import android.media.MediaPlayer
import android.net.Uri
import android.os.Handler
import android.os.Looper

class TapWallpaperService : WallpaperService() {
    override fun onCreateEngine(): Engine = TapEngine()

    inner class TapEngine : Engine() {
        private var player: MediaPlayer? = null
        private var prepared = false
        private var visibleNow = false
        private val handler = Handler(Looper.getMainLooper())

        init { setTouchEventsEnabled(true) }

        override fun onSurfaceCreated(holder: SurfaceHolder) {
            super.onSurfaceCreated(holder)
            prepareVideo(holder)
        }

        private fun prepareVideo(holder: SurfaceHolder) {
            releasePlayer()
            val raw = getSharedPreferences("livetap", MODE_PRIVATE).getString("video_uri", null) ?: return
            try {
                player = MediaPlayer().apply {
                    setDataSource(this@TapWallpaperService, Uri.parse(raw))
                    setSurface(holder.surface)
                    isLooping = false
                    setOnPreparedListener { mp ->
                        prepared = true
                        mp.seekTo(0)
                        mp.pause()
                    }
                    setOnCompletionListener { mp ->
                        // Rewind and pause so the wallpaper rests on the first frame.
                        mp.seekTo(0)
                        handler.postDelayed({
                            try { if (visibleNow && prepared) mp.pause() } catch (_: Exception) { }
                        }, 180)
                    }
                    setOnErrorListener { _, _, _ -> prepared = false; true }
                    prepareAsync()
                }
            } catch (_: Exception) { releasePlayer() }
        }

        override fun onTouchEvent(event: MotionEvent) {
            super.onTouchEvent(event)
            if (event.action == MotionEvent.ACTION_UP) {
                val mp = player
                if (prepared && mp != null && visibleNow) {
                    try {
                        mp.seekTo(0)
                        mp.start()
                    } catch (_: Exception) { }
                }
            }
        }

        override fun onVisibilityChanged(visible: Boolean) {
            visibleNow = visible
            if (!visible) {
                try { player?.pause() } catch (_: Exception) { }
            }
        }

        override fun onSurfaceDestroyed(holder: SurfaceHolder) {
            visibleNow = false
            releasePlayer()
            super.onSurfaceDestroyed(holder)
        }

        private fun releasePlayer() {
            prepared = false
            try { player?.setOnPreparedListener(null); player?.setOnCompletionListener(null); player?.release() } catch (_: Exception) { }
            player = null
        }

        override fun onDestroy() { releasePlayer(); super.onDestroy() }
    }
}
