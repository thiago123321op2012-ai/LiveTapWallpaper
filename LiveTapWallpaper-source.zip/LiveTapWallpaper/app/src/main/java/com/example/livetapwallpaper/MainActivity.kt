package com.example.livetapwallpaper

import android.app.WallpaperManager
import android.content.ComponentName
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class MainActivity : ComponentActivity() {
    private val prefs by lazy { getSharedPreferences("livetap", MODE_PRIVATE) }
    private var status: TextView? = null
    private val pickVideo = registerForActivityResult(androidx.activity.result.contract.ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        if (uri != null) {
            try {
                contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
                prefs.edit().putString("video_uri", uri.toString()).apply()
                status?.text = "Vídeo selecionado! Agora toque em Aplicar papel de parede."
            } catch (e: Exception) {
                Toast.makeText(this, "Não consegui salvar o acesso ao vídeo. Tente selecionar novamente.", Toast.LENGTH_LONG).show()
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(28, 36, 28, 28)
        }
        root.addView(TextView(this).apply {
            text = "LiveTap Wallpaper"
            textSize = 26f
            gravity = Gravity.CENTER
        }, match(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        root.addView(TextView(this).apply {
            text = "Escolha um vídeo curto. O primeiro quadro fica parado; ao tocar no papel de parede, o vídeo toca uma vez e volta ao início.\n\nDica: exporte a Live Photo do iPhone como vídeo MP4 antes de selecionar."
            textSize = 16f
            setPadding(0, 22, 0, 22)
        }, match(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        status = TextView(this).apply {
            text = if (prefs.getString("video_uri", null) == null) "Nenhum vídeo selecionado." else "Vídeo selecionado anteriormente."
            textSize = 14f
            setPadding(0, 8, 0, 16)
        }
        root.addView(status)
        root.addView(Button(this).apply {
            text = "1. Escolher vídeo / Live Photo"
            setOnClickListener { pickVideo.launch(arrayOf("video/mp4", "video/*")) }
        }, match(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        root.addView(Button(this).apply {
            text = "2. Aplicar papel de parede"
            setOnClickListener {
                if (prefs.getString("video_uri", null).isNullOrBlank()) {
                    Toast.makeText(this@MainActivity, "Escolha um vídeo primeiro.", Toast.LENGTH_SHORT).show()
                } else {
                    try {
                        val intent = Intent(WallpaperManager.ACTION_CHANGE_LIVE_WALLPAPER).apply {
                            putExtra(WallpaperManager.EXTRA_LIVE_WALLPAPER_COMPONENT, ComponentName(this@MainActivity, TapWallpaperService::class.java))
                        }
                        startActivity(intent)
                    } catch (e: Exception) {
                        Toast.makeText(this@MainActivity, "Não foi possível abrir a prévia do papel de parede.", Toast.LENGTH_LONG).show()
                    }
                }
            }
        }, match(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        setContentView(root)
    }

    private fun match(w: Int, h: Int) = LinearLayout.LayoutParams(w, h).apply { bottomMargin = 12 }
}
